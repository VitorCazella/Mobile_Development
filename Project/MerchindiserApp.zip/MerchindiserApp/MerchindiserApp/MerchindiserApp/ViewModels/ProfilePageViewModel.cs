﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace MerchindiserApp.ViewModels
{
	public class ProfilePageViewModel : BaseViewModel
    {
		public ProfilePageViewModel ()
		{
			Title = "Profile";
		}

		public void OnAppearing()
		{
			
		}
	}
}